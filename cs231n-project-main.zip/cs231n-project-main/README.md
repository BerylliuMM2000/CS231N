# cs231n-project
## Resources
1. https://debuggercafe.com/advanced-facial-keypoint-detection-with-pytorch/
2. https://debuggercafe.com/keypoint-and-bounding-box-detection-using-pytorch-keypoint-rcnn/
3. https://www.adagger.com/blog/how-to-train-a-custom-keypoint-detection-model
4. https://github.com/pytorch/vision/tree/main/torchvision/models/detection

## To Do List
* Keypoint RCNN
  1. Pre-processing: manually create box for detection
  2. Rewrite dataset class to fit the model
  3. Cross validation
